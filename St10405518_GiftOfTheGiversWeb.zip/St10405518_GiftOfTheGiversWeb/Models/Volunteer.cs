﻿using System;
using System.ComponentModel.DataAnnotations;

namespace St10405518_GiftOfTheGiversWeb.Models
{
    public class Volunteer
    {
        [Key]
        public int VolunteerID { get; set; }

        [Required, StringLength(100)]
        public required string Name { get; set; }

        [Required, EmailAddress]
        public required string Email { get; set; }

        [Required, Phone]
        public required string PhoneNumber { get; set; }

        public DateTime RegistrationDate { get; set; } = DateTime.Now;
    }
}
